En caso de que necesite compilar la aplicación tendrá que tener en cuenta lo siguiente:
El sistema Visualizador de Árboles Sintácticos necesitará para realizar el make, los siguientes paquetes:
	- g++      -> El make utilizara para compilar el compilador para C++ de g++
	- gtk+-2.0 -> El make realizará la comprobación si dispone de la librería gtk.Este paquete lo puede conseguir instalando la librería libgtk2.0-dev

